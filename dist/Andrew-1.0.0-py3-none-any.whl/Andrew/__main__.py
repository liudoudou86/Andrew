# -*- coding: utf-8 -*-

from Andrew.Cli import main


if __name__ == '__main__':
    main()
# -*- coding: utf-8 -*-

__description__ = "http automation testing framework based on schema."
__version__ = "1.0.0"